package Ejercicio4;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Control {
	
	private Lock mutex = new ReentrantLock(true);
	private boolean noHayRecursos;
	private Condition cNoHayRecursos;
	private int numRecursos;
	private int cont;
	
	public Control(int num) {
		noHayRecursos = false;
		cNoHayRecursos = mutex.newCondition();
		numRecursos = num;
		cont = 0;
	}
	
	public void qrecursos(int id, int num) throws InterruptedException{
		try{
			mutex.lock();
			Thread.sleep(1000);
			System.out.println(" + El prodeso" + id + " quiere " + num + " recursos.") ;
			if(numRecursos == 0 || num > numRecursos || noHayRecursos){
				noHayRecursos = true;
				System.out.println("No hay recursos suficientes para el proceso" + id);
			}
			while(noHayRecursos){
				cont++;
				cNoHayRecursos.await();
			}
			if(num <= numRecursos && !noHayRecursos){
				numRecursos = numRecursos - num;
				System.out.println(" *** El proceso"+ id + " coge " + num + " recursos.");
				System.out.println("Hay " + numRecursos + " recursos.");
			}
		}finally{
			mutex.unlock();
		}
	}
	
	public void librecursos(int id, int num) throws InterruptedException{
		try{
			mutex.lock();
			Thread.sleep(1000);
			System.out.println(" - El proceso" + id + " libera " + num + " recursos.");
			numRecursos += num;
			System.out.println("Hay " + numRecursos + " recursos.");
			if(noHayRecursos){
				while(cont != 0){
					cNoHayRecursos.signal();
					cont--;
				}
			}
			noHayRecursos = false;
		}finally{
			mutex.unlock();
		}
		
	}
}
