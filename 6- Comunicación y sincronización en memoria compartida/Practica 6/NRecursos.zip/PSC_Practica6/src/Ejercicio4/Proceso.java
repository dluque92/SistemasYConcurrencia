package Ejercicio4;

import java.util.Random;

public class Proceso extends Thread{

	Control control;
	int id;
	Random r;
	
	public Proceso(int i, Control c) {
		id = i;
		control = c;
		r = new Random();
	}
	
	public void run(){
		try{
			while(true){
				int num = r.nextInt(5)+1;
				control.qrecursos(id, num);
				control.librecursos(id, num);
			}
		}catch(InterruptedException e){
			
		}
	}
}
