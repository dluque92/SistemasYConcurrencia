package Ejercicio4;

public class Main {

	private static final int N = 10;
	private static final int NUM_RECURSOS = 10;
	
	public static void main(String[] args) {
		
		Control control = new Control(NUM_RECURSOS);
		Proceso[] procesos = new Proceso[N];
		
		for(int i = 0; i < N; i++){
			procesos[i] = new Proceso(i, control);
		}
		
		for(int i = 0; i < N ; i++){
			procesos[i].start();
		}
		
		try {
			for(int i = 0; i < N ; i++){
				procesos[i].join();
			}
		} catch (InterruptedException e) {
			
		}

	}

}
