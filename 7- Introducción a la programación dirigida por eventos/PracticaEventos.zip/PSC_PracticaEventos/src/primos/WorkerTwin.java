package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.util.List;

import javax.swing.SwingWorker;

public class WorkerTwin extends SwingWorker<Void, Primos>{

	private int n;
	private Panel panel;
	
	public WorkerTwin(int n,Panel panel){
		this.n = n;
		this.panel = panel;
	}

	private boolean esPrimo(int a) {
		boolean es = true;
		int div = 2;
		while (es && div*div<=a) {
			es = (a % div != 0);
			div++;
		}
		return es;
	}
	
	@Override
	protected Void doInBackground() throws Exception {
		this.setProgress(0);
		panel.mensajeTwin("Calculado Primos Twin ...");
		int nPrimosTwin = 0;
		int posPrimo1 = 2;
		int posPrimo2;
		while (nPrimosTwin<n && !this.isCancelled()) {
			if (esPrimo(posPrimo1)) {
				posPrimo2 = posPrimo1 + 2;
				if (esPrimo(posPrimo2)) {
					publish(new Primos(posPrimo1, posPrimo2,nPrimosTwin));
					nPrimosTwin++;
					this.setProgress(100*nPrimosTwin/n);
				}
			}
			posPrimo1++;
		}
		if (this.isCancelled()) {
			panel.mensajeTwin("Tarea Cancelada.");
		} else
			panel.mensajeTwin("Primos Twin Calculados.");
		return null;
	}
	
	public void process(List<Primos> lista) {
		try {
			panel.escribePrimosTwin(lista);
			
		} catch (Exception e) {
			//e.printStackTrace();
			panel.mensajeTwin("Tarea cancelada");
		}
	}

}
