package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.util.List;

import javax.swing.SwingWorker;

public class WorkerSexy extends SwingWorker<Void, Primos> {

	private int n;
	private Panel panel;
	
	public WorkerSexy(int n,Panel panel){
		this.n = n;
		this.panel = panel;
	}
	
	private boolean esPrimo(int a) {
		boolean es = true;
		int div = 2;
		while (es && div*div<=a) {
			es = (a % div != 0);
			div++;
		}
		return es;
	}

	@Override
	protected Void doInBackground() throws Exception {
		this.setProgress(0);
		panel.mensajeSexy("Calculado Primos Sexy ...");
		int nPrimosSexy = 0;
		int posPrimo1 = 2;
		int posPrimo2;
		while (nPrimosSexy<n && !this.isCancelled()) {
			if (esPrimo(posPrimo1)) {
				posPrimo2 = posPrimo1 + 6;
				if (esPrimo(posPrimo2)) {
					publish(new Primos(posPrimo1, posPrimo2,nPrimosSexy));
					nPrimosSexy++;
					this.setProgress(100*nPrimosSexy/n);
				}
			}
			posPrimo1++;
		}
		if (this.isCancelled()) {
			panel.mensajeSexy("Tarea Cancelada.");
		} else
			panel.mensajeSexy("Primos Sexy calculados.");
		return null;
	}
	
	public void process(List<Primos> lista) {
		try {
			panel.escribePrimosSexy(lista);
			
		} catch (Exception e) {
			//e.printStackTrace();
			panel.mensajeSexy("Tarea cancelada");
		}
	}

}
