package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.util.List;

import javax.swing.SwingWorker;

public class WorkerCousin extends SwingWorker<Void, Primos>{
	

	private int n;
	private Panel panel;

	public WorkerCousin(int n,Panel panel){
		this.n = n;
		this.panel = panel;
	}
	
	private boolean esPrimo(int a) {
		boolean es = true;
		int div = 2;
		while (es && div*div<=a) {
			es = (a % div != 0);
			div++;
		}
		return es;
	}

	@Override
	protected Void doInBackground() throws Exception{
		this.setProgress(0);
		panel.mensajeCousin("Calculado Primos Cousin ...");
		int nPrimosCousin = 0;
		int posPrimo1 = 2;
		int posPrimo2;
		while (nPrimosCousin<n && !this.isCancelled()) {
			if (esPrimo(posPrimo1)) {
				posPrimo2 = posPrimo1 + 4;
				if (esPrimo(posPrimo2)) {
					publish(new Primos(posPrimo1, posPrimo2,nPrimosCousin));
					nPrimosCousin++;
					this.setProgress(100*nPrimosCousin/n);
				}
			}
			posPrimo1++;
		}
		if (this.isCancelled()) {
			panel.mensajeCousin("Tarea cancelada.");
		} else
			panel.mensajeCousin("Primos Cousin Calculados.");
		return null;
	}
	
	public void process(List<Primos> lista) {
		try {
			panel.escribePrimosCousin(lista);
			
		} catch (Exception e) {
			//e.printStackTrace();
			panel.mensajeTwin("Tarea cancelada.");
		}
	}

}
