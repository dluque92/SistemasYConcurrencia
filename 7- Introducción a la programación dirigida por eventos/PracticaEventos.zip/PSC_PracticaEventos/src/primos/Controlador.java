package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.awt.event.*;

public class Controlador implements ActionListener{

	private Panel panel;
	
	private WorkerCousin wc;
	private WorkerSexy ws;
	private WorkerTwin wt;
	
	private ContBarraCousin bc;
	private ContBarraSexy bs;
	private ContBarraTwin bt;
	
	public Controlador(Panel panel, ContBarraCousin barC, ContBarraSexy barS, ContBarraTwin barT){
		this.panel = panel;
		bc = barC;
		bs = barS;
		bt = barT;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "FIN": 	
			if (wt!=null){
				wt.cancel(false);
			}
			if (wc!=null){
				wc.cancel(false);
			}
			if (ws!=null){
				ws.cancel(false);
			}
			panel.mensaje("Cancelado");
			break;
						
		case "TWIN":	
			panel.limpiaAreaTwin();
			wt = new WorkerTwin(panel.numero1(),panel);
			wt.addPropertyChangeListener(bt);
			wt.execute();
			break;
						
		case "COUSIN":	
			panel.limpiaAreaCousin();
			wc = new WorkerCousin(panel.numero2(),panel);
			wc.addPropertyChangeListener(bc);
			wc.execute();
			break;
						
		case "SEXY":	
			panel.limpiaAreaSexy();
			ws = new WorkerSexy(panel.numero3(),panel);
			ws.addPropertyChangeListener(bs);
			ws.execute();
			break;
		}		
	}
}
