package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.List;

@SuppressWarnings("serial")
public class Panel extends JPanel{
	
	private JLabel etiqueta1 = new JLabel("cu�ntos de primos twin quieres?");
	private JTextField numero1 = new JTextField(3);
	private JLabel etiqueta2 = new JLabel("cu�ntos de primos cousin quieres?");
	private JTextField numero2 = new JTextField(3);
	private JLabel etiqueta3 = new JLabel("cu�ntos de primos sexy quieres?");
	private JTextField numero3 = new JTextField(3);
	private JLabel mensaje = new JLabel("GUI creada");
	private JTextArea listaPrimos1 = new JTextArea(10,40);
	private JTextArea listaPrimos2 = new JTextArea(10,40);
	private JTextArea listaPrimos3 = new JTextArea(10,40);
	private JScrollPane scroll1 = new JScrollPane(listaPrimos1);
	private JScrollPane scroll2 = new JScrollPane(listaPrimos2);
	private JScrollPane scroll3 = new JScrollPane(listaPrimos3);
	private JLabel mensaje1 = new JLabel("Area  primos 'twin' creada");
	private JLabel mensaje2 = new JLabel("Area  primos 'cousin' creada");
	private JLabel mensaje3 = new JLabel("Area  primos 'sexy' creada");
	private JButton fin = new JButton("Cancelar");
	
	private JProgressBar progreso1 = new JProgressBar(0,100);
	private JProgressBar progreso2 = new JProgressBar(0,100);
	private JProgressBar progreso3 = new JProgressBar(0,100);
	
	
	public Panel(){
		this.setLayout(new BorderLayout());
		JPanel norte = new JPanel();
		norte.add(fin);
		
		JPanel centro = new JPanel();
		centro.setLayout(new GridLayout(1,3));
		
		JPanel izdarriba = new JPanel();
		izdarriba.add(etiqueta1);
		izdarriba.add(numero1);
		
		JPanel izdabajo = new JPanel();
		izdabajo.add(mensaje1); 
		izdabajo.add(progreso1);
		
		JPanel centroarriba = new JPanel();
		centroarriba.add(etiqueta2);
		centroarriba.add(numero2);
		
		JPanel centroabajo = new JPanel();
		centroabajo.add(mensaje2); 
		centroabajo.add(progreso2);
		
		JPanel dcharriba = new JPanel();
		dcharriba.add(etiqueta3);
		dcharriba.add(numero3);
		
		JPanel dchabajo = new JPanel();
		dchabajo.add(mensaje3); 
		dchabajo.add(progreso3);
		
		JPanel izquierda = new JPanel();
		izquierda.setLayout(new BorderLayout());
		izquierda.add(BorderLayout.NORTH,izdarriba);
		izquierda.add(BorderLayout.CENTER,scroll1);
		izquierda.add(BorderLayout.SOUTH,izdabajo);
		
		JPanel centro1 = new JPanel();
		centro1.setLayout(new BorderLayout());
		centro1.add(BorderLayout.NORTH,centroarriba);
		centro1.add(BorderLayout.CENTER,scroll2);
		centro1.add(BorderLayout.SOUTH,centroabajo);
		
		JPanel derecha = new JPanel();
		derecha.setLayout(new BorderLayout());
		derecha.add(BorderLayout.NORTH,dcharriba);
		derecha.add(BorderLayout.CENTER,scroll3);
		derecha.add(BorderLayout.SOUTH,dchabajo);
		centro.add(izquierda);centro.add(centro1);centro.add(derecha);
		this.add(BorderLayout.NORTH, norte);
	    this.add(BorderLayout.CENTER,  centro);
	    this.add(BorderLayout.SOUTH,mensaje);
	    
	    progreso1.setValue(0);
		progreso1.setStringPainted(true);
		progreso2.setValue(0);
		progreso2.setStringPainted(true);
		progreso3.setValue(0);
		progreso3.setStringPainted(true);
	}
	
	public void controlador(ActionListener ctr){
		fin.addActionListener(ctr);
		fin.setActionCommand("FIN");
		numero1.addActionListener(ctr);
		numero1.setActionCommand("TWIN");
		numero2.addActionListener(ctr);
		numero2.setActionCommand("COUSIN");
		numero3.addActionListener(ctr);
		numero3.setActionCommand("SEXY");
		
	}
	public int numero1() {
		return Integer.parseInt(numero1.getText());
	}
	public int numero2() {
		return Integer.parseInt(numero2.getText());
	}
	
	public int numero3() {
		return Integer.parseInt(numero3.getText());
	}

	public void escribePrimosTwin(List<Primos> list){
		for (int i=0; i<list.size(); i++) {
			if (list.get(i).pos()%5 == 0){
				listaPrimos1.append("\n");
			}
			listaPrimos1.append(list.get(i).toString());
		}
	}	
	
	public void escribePrimosCousin(List<Primos> list){
		for (int i=0; i<list.size(); i++) {
			if (list.get(i).pos()%5 == 0){
				listaPrimos2.append("\n");
			}
			listaPrimos2.append(list.get(i).toString());
		}
	}
	
	
	public void escribePrimosSexy(List<Primos> list){
		for (int i=0; i<list.size(); i++) {
			if (list.get(i).pos()%5 ==0){
				listaPrimos3.append("\n");
			}
			listaPrimos3.append(list.get(i).toString());
		}
	}
	public void limpiaAreaTwin(){
		listaPrimos1.setText("");
	}
	
	public void limpiaAreaCousin(){
		listaPrimos2.setText("");
	}
		
	
	public void limpiaAreaSexy(){
		listaPrimos3.setText("");
	}
		
	public void mensaje(String str){
		mensaje.setText(str);
	}
	
	public void mensajeTwin(String str){
		mensaje1.setText(str);
	}

	public void mensajeCousin(String str){
		mensaje2.setText(str);
	}
	
	public void mensajeSexy(String str){
		mensaje3.setText(str);
	}
	
	public void progresoTwin(int n) {
		progreso1.setValue(n);
	}
	public void progresoCousin(int n) {
		progreso2.setValue(n);
	}
	public void progresoSexy(int n) {
		progreso3.setValue(n);
	}
}
