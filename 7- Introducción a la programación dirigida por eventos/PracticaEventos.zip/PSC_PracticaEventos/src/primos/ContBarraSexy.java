package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ContBarraSexy implements PropertyChangeListener{

	private Panel panel;
	
	public ContBarraSexy(Panel panel) {
		this.panel = panel;
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent arg0) {
		if (arg0.getPropertyName().equals("progress")){
			panel.progresoSexy((Integer)arg0.getNewValue());
		}
	}
}
