package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

public class Primos {
	private long a;
	private long b;
	private int pos;
	
	public Primos(long a,long b,int pos){
		this.a = a;
		this.b = b;
		this.pos = pos;
	}

	public String toString(){
		return pos + ":(" + a + ", " + b + ") ";
	}
	public int pos(){
		return pos;
	}
}
