package primos;

/* 
 * Autor: David Luque Fern�ndez
 * Curso: 2� Ing. Software - A
 */

import javax.swing.*;

public class Principal {

	public static void crearGUI(JFrame ventana){
		Panel panel = new Panel();
		
		ContBarraCousin contC = new ContBarraCousin(panel);
		ContBarraSexy contS = new ContBarraSexy(panel);
		ContBarraTwin contT = new ContBarraTwin(panel);
		
		Controlador ctr = new Controlador(panel, contC, contS, contT);
		panel.controlador(ctr);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setContentPane(panel);
		ventana.pack();
		ventana.setVisible(true);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				JFrame ventana = new JFrame("Numeros primos");
				crearGUI(ventana);
			}
		});
	}
	
	

}
