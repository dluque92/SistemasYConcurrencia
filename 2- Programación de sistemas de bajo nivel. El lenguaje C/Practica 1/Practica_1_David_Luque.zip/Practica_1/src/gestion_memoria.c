#include "gestion_memoria.h"
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>
#define INICIO		0
#define MAX			999
/*------------------------------------------------------------------------*/

T_Manejador Crear_nodo(unsigned i, unsigned f, T_Manejador s){
	T_Manejador p = malloc(sizeof(*p));
	if (p != NULL) {
		p->inicio = i;
		p->fin = f;
		p->sig = s;
	}
	return p;
}

/*------------------------------------------------------------------------*/

void Crear(T_Manejador* manejador){
	*manejador = Crear_nodo(INICIO, MAX, NULL);
}

/*------------------------------------------------------------------------*/

void Destruir(T_Manejador* manejador){
	while (*manejador != NULL) {
		T_Manejador aux = *manejador;
		*manejador = (*manejador)->sig;
		free(aux);
	}
}

/*------------------------------------------------------------------------*/

void Obtener(T_Manejador *manejador, unsigned tam, unsigned* dir, unsigned* ok){
	if (tam > 0) {
		T_Manejador a = NULL;
		T_Manejador p = *manejador;
		while ((p != NULL)&&((p->fin-p->inicio+1) < tam)) {
			a = p;
			p = p->sig;
		}
		if (p == NULL) {
			*ok = 0;
			*dir = 0;
		} else {
			*ok = 1;
			*dir = p->inicio;
			if ((p->fin-p->inicio+1) == tam) {
				if (a == NULL) {
					*manejador = (*manejador)->sig;
				} else {
					a->sig = p->sig;
				}
				free(p);
			} else { /* ((p->fin-p->inicio+1) > tam) */
				p->inicio += tam;
				assert(p->inicio <= p->fin);
			}
		}
	}
}

/*------------------------------------------------------------------------*/

void Mostrar(T_Manejador manejador){
	unsigned ant_fin = 0;
	T_Manejador p = manejador;
	printf("-----\n");
	while (p != NULL) {
		if (ant_fin < p->inicio) {
			printf("%2d - %2d: Ocupada\n", ant_fin, p->inicio-1);
		}
		printf("%2d - %2d: Disponible\n", p->inicio, p->fin);
		ant_fin = p->fin+1;
		p = p->sig;
	}
	if (ant_fin < MAX) {
		printf("%2d - %2d: Ocupada\n", ant_fin, MAX);
	}
	printf("-----\n");
}

/*------------------------------------------------------------------------*/

void Insertar_Ord(T_Manejador *manejador, unsigned tam, unsigned dir){
	assert(tam > 0);
	if ((*manejador == NULL)||(dir < (*manejador)->inicio)) {
		assert((*manejador==NULL)||((dir+tam-1)<(*manejador)->inicio));
		*manejador = Crear_nodo(dir, dir+tam-1, *manejador);
	} else {
		T_Manejador a = *manejador;
		T_Manejador p = a->sig;
		while ((p != NULL)&&(dir > p->fin)) {
			a = p;
			p = p->sig;
		}
		//assert(a->fin < dir);
		assert((p == NULL)||(dir+tam-1 < p->inicio));
		a->sig = Crear_nodo(dir, dir+tam-1, p);
	}
}

/*------------------------------------------------------------------------*/

void Compactar(T_Manejador *manejador){
	if (*manejador != NULL) {
		T_Manejador a = *manejador;
		T_Manejador p = a->sig;
		while (p != NULL) {
			if (a->fin+1 == p->inicio) {
				a->fin = p->fin;
				a->sig = p->sig;
				free(p);
			} else {
				a = a->sig;
			}
			p = a->sig;
		}
	}
}

/*------------------------------------------------------------------------*/

void Devolver(T_Manejador *manejador, unsigned tam, unsigned dir){
	if (tam > 0) {
		Insertar_Ord(manejador, tam, dir);
		Compactar(manejador);
	}
}

