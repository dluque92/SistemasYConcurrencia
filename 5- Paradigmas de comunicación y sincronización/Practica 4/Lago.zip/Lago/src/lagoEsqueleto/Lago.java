package lagoEsqueleto;

public class Lago {
	
	private volatile int nivel = 0;
	private Peterson petersonRio = new Peterson(); 
	private Peterson petersonPresa = new Peterson();
	private Peterson petersonGeneral = new Peterson();
	
	public void incrementa(int i){ // para el rio i
		// accede a nivel en exclusi�n mutua
		petersonGeneral.preprotocolo(0);
		petersonRio.preprotocolo(i);
		nivel++;
		petersonRio.postprotocolo(i);
		petersonGeneral.postprotocolo(0);
		System.out.println("Rio " + i + " ha incrementado el nivel "+nivel);
	}


	public void decrementa(int i){ // para la presa i
		// solo puedo decrementar si el lago no est� vac�o
		// accedo en exclusi�n mutua
		petersonGeneral.preprotocolo(1);
		petersonPresa.preprotocolo(i);
		while(get(i) == 0){
			Thread.yield();
		}
		nivel--;
		petersonPresa.postprotocolo(i);
		petersonGeneral.postprotocolo(1);
		System.out.println("Presa " + i + " ha decrementado el nivel "+nivel);
	}
	
	public int get(int i) {
		int num;
		petersonGeneral.preprotocolo(1);
		petersonPresa.preprotocolo(i);
		num = nivel;
		petersonPresa.postprotocolo(i);
		petersonGeneral.postprotocolo(1);
		return num;
	}

}
