package lagoEsqueleto;


public class Presa extends Thread{
	
	private Lago lago;
	private int id;
	
	public Presa(Lago lago,int id){
		this.lago = lago;
		this.id = id;
	}
	
	public void run(){
		for (int i= 0; i<1000; i++){
			lago.decrementa(id);
		}
	}

}
